/*
 Copyright (C) 2015 Apple Inc. All Rights Reserved.
 See LICENSE.txt for this sample’s licensing information
 
 Abstract:
 This controller displays labels and specialized labels (Date and Timer).
 */

@import WatchKit;

@interface AAPLLabelDetailController : WKInterfaceController
@end
