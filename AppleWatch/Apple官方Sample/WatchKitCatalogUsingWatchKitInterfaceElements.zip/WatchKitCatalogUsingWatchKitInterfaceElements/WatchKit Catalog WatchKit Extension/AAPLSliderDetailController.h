/*
 Copyright (C) 2015 Apple Inc. All Rights Reserved.
 See LICENSE.txt for this sample’s licensing information
 
 Abstract:
 This controller displays sliders and their various configurations.
 */

@import WatchKit;

@interface AAPLSliderDetailController : WKInterfaceController
@end
