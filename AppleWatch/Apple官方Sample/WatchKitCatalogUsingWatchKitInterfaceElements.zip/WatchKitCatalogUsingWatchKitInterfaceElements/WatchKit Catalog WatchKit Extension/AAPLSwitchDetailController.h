/*
 Copyright (C) 2015 Apple Inc. All Rights Reserved.
 See LICENSE.txt for this sample’s licensing information
 
 Abstract:
 This controller displays switches and their various configurations.
 */

@import WatchKit;

@interface AAPLSwitchDetailController : WKInterfaceController
@end
